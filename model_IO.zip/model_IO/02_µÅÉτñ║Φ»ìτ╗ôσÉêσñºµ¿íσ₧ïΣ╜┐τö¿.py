from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
import os
import dotenv
dotenv.load_dotenv()
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
chat_model = ChatOpenAI(
    model="gpt-5.2",

)
prompt_template = PromptTemplate(
    template="你是一个{role},你的名字是{name},给我介绍langchian",
)

prompt = prompt_template.invoke(input={"name":"小智","role":"人工智能专家"})
response = chat_model.invoke(prompt)
print(response.content)