from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
import dotenv
import os

from sqlalchemy.ext.mypy.apply import add_additional_orm_attributes

system_message = SystemMessage(content="你是一个英语教学方向的专家")
humanMessage = HumanMessage(content="帮我制定一个英语六级的学习计划")

message = [system_message,humanMessage]
dotenv.load_dotenv()
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
# 1.获取对话模型
chat_model = ChatOpenAI(
    model="gpt-4o-mini",
)
# 2.调用对话模型
response = chat_model.invoke(message)
# invoke()的输入可以是多种类型 1.字符串 2.消息列表（AIMessage)

# 3.处理相应数据
print(response.content)