from functools import partial

from langchain_core.prompts import PromptTemplate

# 1.如何获取实例
# 参数中必须要指明：input_variables、template
# 方式1
# prompt_template= PromptTemplate(
#     template="你是一个{role},你的名字是{name}",
#     input_variables=["role","name"]
# )
# 1.1 方式2
# prompt_template= PromptTemplate.from_prompt_template(
#     template="你是一个{role},你的名字是{name}",
# )
# 1.2 填充实例中的变量
# prompt_template.format(role="人工智能专家",name="小智")
# 2.两种特殊结构的使用
# 2.1 方式1
# prompt_template= PromptTemplate.from_template(
#     template="你是一个{role},你的名字是{name}",
#     partial_variables={"role":"人工智能专家"}
# )
# prompt = prompt_template.format(name="小智")
# print(prompt)
# 2.2 方式2
# prompt_template= PromptTemplate(
#     template="你是一个{role},你的名字是{name}",
#     input_variables=["role","name"]
# )
# template1 = prompt_template.partial(role="国内智能专家")
# prompt = template1.format(name="小智")
# print(prompt)
# 2.3 方式3
# prompt_template= PromptTemplate(
#     template="你是一个{role},你的名字是{name}",
#     input_variables=["role","name"]
# ).partial(role="国内智能专家")
#
# prompt = prompt_template.format(name="小智")
# print(prompt)
# 2.第二种结构 invoke()
prompt_template = PromptTemplate(
    template="你是一个{role},你的名字是{name}",
)

prompt = prompt_template.invoke(input={"name":"小智","role":"人工智能专家"})
print(prompt)
# 3.给变量赋值的两种方式
# 4.结合大模型的使用
