# 1.关于对话模型中消息message的使用
import dotenv
from langchain_openai import ChatOpenAI
import os
dotenv.load_dotenv()
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
# 1.获取对话模型
chat_model = ChatOpenAI(
    model="gpt-4o-mini",
)
# 2.调用对话模型
response = chat_model.invoke("你是谁")
# invoke()的输入可以是多种类型 1.字符串 2.消息列表（AIMessage)

# 3.处理相应数据
print(response)
