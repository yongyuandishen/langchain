import time
# 同步调用
# def call_model():
# # 模拟同步API调用
#     print("开始调用模型...")
#     time.sleep(5) # 模拟调用等待,单位：秒
#     print("模型调用完成。")
# def perform_other_tasks():
#     # 模拟执行其他任务
#     for i in range(5):
#         print(f"执行其他任务 {i + 1}")
#         time.sleep(1) # 单位：秒
# def main():
#     start_time = time.time()
#     call_model()
#     perform_other_tasks()
#     end_time = time.time()
#     total_time = end_time - start_time
#     return f"总共耗时：{total_time}秒"
# # 运行同步任务并打印完成时间
# main_time = main()
# print(main_time)

# 异步调用
import asyncio
import time
async def async_call(llm):
    await asyncio.sleep(5) # 模拟异步操作
    print("异步调用完成")
async def perform_other_tasks():
    await asyncio.sleep(5) # 模拟异步操作
    print("其他任务完成")
async def run_async_tasks():
    start_time = time.time()
    await asyncio.gather(
    async_call(None), # 示例调用，使用None模拟LLM对象
    perform_other_tasks()
    )
    end_time = time.time()
    return f"总共耗时：{end_time - start_time}秒"
# # 正确运行异步任务的方式
# if __name__ == "__main__":
# # 使用 asyncio.run() 来启动异步程序
# result = asyncio.run(run_async_tasks())
# print(result)
# 在 Jupyter 单元格中直接调用
if __name__ == "__main__":
# 使用 asyncio.run() 来启动异步程序
    result = asyncio.run(run_async_tasks())
    print(result)