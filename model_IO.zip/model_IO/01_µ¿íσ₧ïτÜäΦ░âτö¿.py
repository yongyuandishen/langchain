from langchain_openai import ChatOpenAI
import os
import dotenv
dotenv.load_dotenv()
chat_model = ChatOpenAI(
    model="gpt-5.2",
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),

)

response = chat_model.invoke("什么是langchain")

print(response.content)