from langchain_core.prompts import FewShotPromptTemplate,ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
import os
import dotenv
dotenv.load_dotenv()
# 方式1
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")

chat_model = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.7,
    max_tokens=512,
)
# example_prompt = PromptTemplate.from_template(
#     template="input:{input}\noutput:{output}",
# )
# examples = [
#     {"input": "北京天气怎么样", "output": "北京市"},
#     {"input": "南京下雨吗", "output": "南京市"},
#     {"input": "武汉热吗", "output": "武汉市"}
# ]
# few_shot_template = FewShotPromptTemplate(
#     example_prompt=example_prompt,
#     examples=examples,
#     suffix ="input:{input}\noutput:",
#     input_variables=["input"]
#
# )
# 方式2
# 1.示例消息格式
examples = [
    {"input": "1+1等于几？", "output": "1+1等于2"},
    {"input": "法国的首都是？", "output": "巴黎"}
]
# 2.定义示例的消息格式提示词模版
msg_example_prompt = ChatPromptTemplate.from_messages([
    ("human", "{input}"),
    ("ai", "{output}"),
    ])
# 3.定义FewShotChatMessagePromptTemplate对象
few_shot_prompt = FewShotChatMessagePromptTemplate(
    example_prompt=msg_example_prompt,
    examples=examples
)
final_chat_prompt = ChatPromptTemplate.from_messages([
    ("system", "你是一个有用的助手。"),  # 系统消息
    few_shot_prompt,  # few-shot示例
    ("human", "{input}"),  # 用户输入
])
few_shot_prompt = final_chat_prompt.invoke({"input":"2*3等于几"})
response = chat_model.invoke(few_shot_prompt)
print(response.content)
