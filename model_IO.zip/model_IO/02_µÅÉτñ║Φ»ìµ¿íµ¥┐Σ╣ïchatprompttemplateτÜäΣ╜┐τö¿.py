# 调用提示词模板的几种方法：invoke()\format()\format()_messages()\format_prompt()
# 方式1 构造方法
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_openai import ChatOpenAI
# import dotenv
# import os
# dotenv.load_dotenv()
# os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
# os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
# chat_model = ChatOpenAI(
#     model="gpt-4o-mini",
#
# )
#
# chat_prompt_template=ChatPromptTemplate(
#     messages=[("system","你是一个AI助手，你的名字叫{name}"),
#               ("human","我的问题是{question}")],
#     input_variables=["name","question"],
# )
#
# prompt_template = chat_prompt_template.invoke(input={"name":"小智","question":"1+2*3=?"})
# response = chat_model.invoke(prompt_template)
# print(response.content)
# # 方式2
# chat_prompt_template=ChatPromptTemplate.from_message(
#     messages=[("system","你是一个AI助手，你的名字叫{name}"),
#               ("human","我的问题是{question}")],
#     input_variables=["name","question"],
# )
#
# response = chat_prompt_template.invoke(input={"name":"小智","question":"1+2*3=?"})
# print(response)
from langchain_core.messages import HumanMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.prompts.chat import MessagesPlaceholder
from langchain_openai import ChatOpenAI
import dotenv
import os
dotenv.load_dotenv()
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
chat_model = ChatOpenAI(
    model="gpt-4o-mini",

)

chat_prompt_template=ChatPromptTemplate.from_messages([
    ("system","你是一个AI助手{name}"),
    MessagesPlaceholder("history"),
    ("human","{question}")]

)

prompt_value = chat_prompt_template.format_messages(
    name = "小智",
    history = [HumanMessage(content="1*2*3 = ?")],
    question = "我刚才的问题是什么",
)

response = chat_model.invoke(prompt_value)
print(response.content)
