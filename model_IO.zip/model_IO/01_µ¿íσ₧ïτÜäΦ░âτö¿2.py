from langchain_openai import ChatOpenAI
import os
import dotenv
dotenv.load_dotenv()
# 方式1
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
# 方式2
# chat_model = ChatOpenAI
#     model="gpt-5.2",
#     base_url=os.getenv("OPENAI_BASE_URL"),
#     api_key=os.getenv("OPENAI_API_KEY"),
#
# )

chat_model = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.7,
    max_tokens=512,
)

response = chat_model.invoke("什么是langchain")

print(response.content)