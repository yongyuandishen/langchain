import os
import dotenv
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
dotenv.load_dotenv()

# 测试1
sys_message = SystemMessage(
    content="我是一个人工智能助手，我的名字叫小智"
)
# humanMessage = HumanMessage(
#     content="猫王是一只猫吗"
# )

# messages = [sys_message, humanMessage]
# os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
# os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")
#
# chat_model = ChatOpenAI(
#     model="gpt-4o-mini"
# )
#
# response = chat_model.invoke(messages)
# print(response.content)
# response1 = chat_model.invoke("你叫什么名字")
# print(response1.content)
# 大模型本身是没有记忆能力的

# 测试2
humanMessage = HumanMessage(
    content="猫王是一只猫吗"
)
humanMessage1 = HumanMessage(
    content="你叫什么名字"
)
messages = [sys_message, humanMessage,humanMessage1]
os.environ["OPENAI_API_KEY"]=os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_BASE_URL"]=os.getenv("OPENAI_BASE_URL")

chat_model = ChatOpenAI(
    model="gpt-4o-mini"
)

response = chat_model.invoke(messages)
print(response.content)

